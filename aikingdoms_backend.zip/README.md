# AI Kingdoms: Genesis Backend

Dieses Projekt ist das Grundgerüst für das FastAPI-Backend von AI Kingdoms: Genesis.

## Start

```bash
uvicorn main:app --reload
```

## Deployment

Dieses Projekt ist bereit für Railway Deployment.