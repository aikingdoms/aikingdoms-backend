from fastapi import APIRouter
from pydantic import BaseModel
from typing import List

router = APIRouter()

class Building(BaseModel):
    id: int
    name: str
    level: int
    wood_cost: int
    stone_cost: int

# Beispiel-Daten
buildings = [
    Building(id=1, name="Holzhütte", level=1, wood_cost=50, stone_cost=20),
    Building(id=2, name="Steinhaus", level=2, wood_cost=120, stone_cost=100),
]

@router.get("/", response_model=List[Building])
def get_buildings():
    return buildings

@router.get("/{building_id}", response_model=Building)
def get_building(building_id: int):
    for b in buildings:
        if b.id == building_id:
            return b
    return {"error": "Building not found"}