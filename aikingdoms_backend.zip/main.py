from fastapi import FastAPI
from app.routers import buildings

app = FastAPI()

app.include_router(buildings.router, prefix="/buildings", tags=["Buildings"])

@app.get("/")
def read_root():
    return {"message": "Welcome to AI Kingdoms: Genesis API"}